// src/app/page.tsx
import { redirect } from "next/navigation";

export default function Home() {
  // เปิด / แล้วให้ไป login
  redirect("/login");
}
